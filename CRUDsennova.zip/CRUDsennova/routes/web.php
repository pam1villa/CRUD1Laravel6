<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//----------------------Acciones Aprendiz------------------------
Route::get('Aprendiz/delete/{id}', 'AprendizController@DeleteApre') ->name('DeleteAprendiz');

Route::get('Aprendiz/update/{id}', 'AprendizController@UpdateApre') ->name('UpdateAprendiz');

Route::get('Aprendiz/view', 'AprendizController@ViewApre') ->name('ViewAprendiz');

Route::get('Aprendiz/insert', function () {
    return view('Aprendiz/insert');
})->name('InsertAprendiz');

Route::post('Aprendiz/insert', 'AprendizController@InsertApre')  ->name('InsertAprendiz');

Route::post('Aprendiz/update', 'AprendizController@UpdateBdApre')  ->name('UpdateBdAprendiz');
