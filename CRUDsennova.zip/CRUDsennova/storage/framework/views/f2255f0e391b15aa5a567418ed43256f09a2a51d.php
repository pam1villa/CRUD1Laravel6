<?php $__env->startSection('contenido'); ?>



<table class="table">
    <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">APREN_Nombre</th>
            <th scope="col">APREN_Documento</th>
            <th scope="col">APREN_Tipo_Documento</th>
            <th scope="col">APREN_Genero</th>
            <th scope="col">APREN_Estado</th>
            <th scope="col">APREN_Foto</th>

            

            <th scope="col">Acciones</th>
    </tr>
    </thead>


    <tbody>
    <?php $__currentLoopData = $objetoretornado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprendiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>

            <td><?php echo e($aprendiz->id); ?></td>
            <td><?php echo e($aprendiz->APREN_Nombre); ?></td>
            <td><?php echo e($aprendiz->APREN_Documento); ?></td>
            <td><?php echo e($aprendiz->APREN_Tipo_Documento); ?></td>
            <td><?php echo e($aprendiz->APREN_Genero); ?></td>
            <td><?php echo e($aprendiz->APREN_Estado); ?></td>
            <td><?php echo e($aprendiz->APREN_Foto); ?></td>

            

            <td>
                
            <a href="<?php echo e(route('DeleteAprendiz', $aprendiz->id)); ?>"><i class='bx bxs-trash'></i></a>
            <a href="<?php echo e(route('UpdateAprendiz', $aprendiz->id)); ?>"><i class='bx bx-refresh'></i></a> 

            </td>
            </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pamela\CRUDsennova\resources\views/Aprendiz/view.blade.php ENDPATH**/ ?>