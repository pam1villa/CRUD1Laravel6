<?php $__env->startSection('contenido'); ?>

    <section id="basic-input">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Registrar Aprendiz</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                
                                
                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Codigo Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su codigo..." name="id"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Nombre Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su nombre..." name="APREN_Nombre"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Documento Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su documento..." name="APREN_Documento"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Tipo Documento</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su tipo de documento..." name="APREN_Tipo_Documento"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Genero Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese el genero con el que se identifica..." name="APREN_Genero"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Estado Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese el genero con el que se identifica..." name="APREN_Genero"/>
                                    </div>
                                    <button class="btn btn-primary" type="submit"  id="guardar">Registrar</button>
                                </div>

                                

                                

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- Basic Inputs end -->


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pamela\CRUDsennova\resources\views/Aprendiz/insert.blade.php ENDPATH**/ ?>