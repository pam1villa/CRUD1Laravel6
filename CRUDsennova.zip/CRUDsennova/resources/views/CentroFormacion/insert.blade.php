@extends('layouts.app')
@section('contenido')

<section id="basic-input">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Registrar Centro De Formacion</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            {{-- <p class="card-text mb-2">
                                Be sure to use <code>.col-form-label-sm</code> or <code>.col-form-label-lg</code> to your
                                <code>&lt;label&gt;</code>s or <code>&lt;legend&gt;</code>s to correctly follow the size of
                                <code>.form-control-lg</code> and <code>.form-control-sm</code>.
                            </p> --}}
                            
                            <div class="mb-1 row">
                                <label for="colFormLabel" class="col-sm-3 col-form-label">Codigo Centro De Formacion</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese el codigo del centro de formacion..." name="id"/>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label for="colFormLabel" class="col-sm-3 col-form-label">Centro De Formacion</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese el nombre del centro de formacion..." name="CENTR_Nombre"/>
                                </div>
                                <button class="btn btn-primary" type="submit">Registrar</button>
                            </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<!-- Basic Inputs end -->


@include('layouts.footer')
@endsection