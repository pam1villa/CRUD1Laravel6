@extends('layouts.app')
@section('contenido')

{{-- <div class="ui sucess mesagge">
    <i class="close icon"></i>
    <div class="header">
        {{session('hecho')}}
    </div>
</div> --}}

<table class="table">
    <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">CENTR_Nombre</th>
        
            {{-- <th scope="col">id_regional</th> --}}
           
            <th scope="col">Acciones</th>
    </tr>
    </thead>


    <tbody>
        @foreach ($objetoretornado as $centroformacion)
        <tr>
        <td>{{ $centroformacion->id }}</td>
        <td>{{ $centroformacion->CENTR_Nombre }}</td>

        <td>
            <a href="{{ route('DeleteCentroFormacion', $centroformacion->id) }}"><i class='bx bxs-trash'></i></a>
            <a href="{{ route('UpdateCentroFormacion', $centroformacion) }}"><i class='bx bx-refresh'></i></a> 
        </td>
        </tr>
@endforeach
</tbody>
</table>

@include('layouts.footer')
@endsection