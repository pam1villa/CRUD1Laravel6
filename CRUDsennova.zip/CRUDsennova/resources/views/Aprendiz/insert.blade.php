@extends('layouts.app')
@section('contenido')

    <section id="basic-input">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Registrar Aprendiz</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                {{-- <p class="card-text mb-2">
                                    Be sure to use <code>.col-form-label-sm</code> or <code>.col-form-label-lg</code> to your
                                    <code>&lt;label&gt;</code>s or <code>&lt;legend&gt;</code>s to correctly follow the size of
                                    <code>.form-control-lg</code> and <code>.form-control-sm</code>.
                                </p> --}}
                                
                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Codigo Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su codigo..." name="id"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Nombre Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su nombre..." name="APREN_Nombre"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Documento Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su documento..." name="APREN_Documento"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Tipo Documento</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese su tipo de documento..." name="APREN_Tipo_Documento"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Genero Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese el genero con el que se identifica..." name="APREN_Genero"/>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Estado Aprendiz</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Ingrese el genero con el que se identifica..." name="APREN_Genero"/>
                                    </div>
                                    <button class="btn btn-primary" type="submit"  id="guardar">Registrar</button>
                                </div>

                                {{-- <div class="row">
                                    <div class="col-md-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-lg-6 col-md-12 mb-1 mb-sm-0">
                                                        <label for="formFile" class="form-label">Seleccione su foto de perfil </label>
                                                        <input class="form-control" type="file" id="formFile" name="APREN_Foto" />
                                                    </div>
                                                </div>
                                            <button class="btn btn-primary" type="submit"  id="guardar">Registrar</button>
                                            </div>
                                        </div>
                                    </div> --}}

                                {{-- <div class="mb-1 row">
                                    <label for="colFormLabel" class="col-sm-3 col-form-label">Identificador Unico Ficha</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="colFormLabel" placeholder="Por modificar..." name="id_ficha"/>
                                    </div>
                                </div> --}}

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- Basic Inputs end -->


@include('layouts.footer')
@endsection