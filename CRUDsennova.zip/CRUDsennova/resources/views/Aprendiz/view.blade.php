@extends('layouts.app')
@section('contenido')

{{-- <div class="ui sucess mesagge">
    <i class="close icon"></i>
    <div class="header">
        {{session('hecho')}}
    </div>
</div> --}}

<table class="table">
    <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">APREN_Nombre</th>
            <th scope="col">APREN_Documento</th>
            <th scope="col">APREN_Tipo_Documento</th>
            <th scope="col">APREN_Genero</th>
            <th scope="col">APREN_Estado</th>
            <th scope="col">APREN_Foto</th>

            {{-- <th>id_ficha</th> --}}

            <th scope="col">Acciones</th>
    </tr>
    </thead>


    <tbody>
    @foreach ($objetoretornado as $aprendiz)

            <tr>

            <td>{{ $aprendiz->id }}</td>
            <td>{{ $aprendiz->APREN_Nombre }}</td>
            <td>{{ $aprendiz->APREN_Documento }}</td>
            <td>{{ $aprendiz->APREN_Tipo_Documento }}</td>
            <td>{{ $aprendiz->APREN_Genero }}</td>
            <td>{{ $aprendiz->APREN_Estado }}</td>
            <td>{{ $aprendiz->APREN_Foto }}</td>

            {{-- <td>{{ $aprendiz->id_ficha }}</td> --}}

            <td>
                
            <a href="{{ route('DeleteAprendiz', $aprendiz->id) }}"><i class='bx bxs-trash'></i></a>
            <a href="{{ route('UpdateAprendiz', $aprendiz->id) }}"><i class='bx bx-refresh'></i></a> 

            </td>
            </tr>
    @endforeach
    </tbody>
</table>

@include('layouts.footer')
@endsection