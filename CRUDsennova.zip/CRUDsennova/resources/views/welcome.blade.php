@extends('layouts.app')

@section('contenido')
    <h1>hola</h1>

@include('layouts.footer')
@endsection