
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;

class ProveedorController extends Controller
{
    //Mètodo pùblico que acciona lo que tenemos.
    public funtion InsertPro(Request $proveedor )
    {
        $instanciaproveedor = new App\Proveedor;
        $instanciaproveedor->nombre = $proveedor->nombre; 
        $instanciaproveedor->telefono = $proveedor->telefono; 
        $instanciaproveedor->direccion = $proveedor->direccion; 
        $instanciaproveedor->save(); 

        return redirect('Proveedor/view');
    }

    public function viewpro()
    {
        $objetoretornado = App\Proveedor::All();
        return view('Proveedor/view',compact('objetoretornado'));
    }
}
