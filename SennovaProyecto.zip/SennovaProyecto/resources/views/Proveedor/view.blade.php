@extends('menu')

@section('plantilla')

<table class="ui blue table">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Direccion</th>
            <th>Telefono</th>
            <th>Acciones</th>
    </tr></thead>
    <tbody>
    
    @foreach ($collection as $item)
            <tr>
            <td></td>
            <td></td>
            <td></td>
            <td>
            <i class="delete icon"></i>
            <i class="sync icon"></i>
            <i class="eye icon"></i>
            </td>
            </tr>
    @endforeach
    </tbody>
</table>

@endsection

//Minuto 41:34