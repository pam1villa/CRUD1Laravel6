 <!DOCTYPE html>
 <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Proyecto Papeleria</title>
        <link rel="stylesheet" href="{{ asset('Css/semantic.min.css') }}">
        <link rel="stylesheet" href="{{ asset('Css/style.css') }}">
        <script src="{{ asset('Js/jquery-3.4.1.min.js') }}"></script>
        <script src="{{ asset('Js/jquery.validate.js') }}"></script>
        <script src="{{ asset('Js/semantic.min.js') }}"></script>
        <script src="{{ asset('Js/notify.js') }}"></script>
        <script src="{{ asset('Js/aplication.js') }}"></script>
    </head>

<body>
    <div class="ui stackable menu">
        <div class="item">
            <img src="{{ asset('Img/logo.jpg') }}">
        </div>
        <div class="ui dropdown item">Proveedor<i class="dropdown icon"></i>
            <div class="menu">
                <a href="#">
                    <div class="item">Listado de Proveedores</div>
                </a>
                <a href="{{ route('insertpro') }}">
                    >
                    <div class="item">Registrar Proveedores</div>
                </a>
            </div>
        </div>
        <div class="ui dropdown item">Producto<i class="dropdown icon"></i>
            <div class="menu">
                <a href="#">
                    <div class="item">Listado de Clientes</div>
                </a>
                <a href="#">
                    <div class="item">Registrar Clientes</div>
                </a>
            </div>
        </div>
        <div class="ui dropdown item">Producto<i class="dropdown icon"></i>
            <div class="menu">
                <a href="#">
                    <div class="item">Listado de Producto</div>
                </a>
                <a href="#">
                    <div class="item">Registrar Productos</div>
                </a>
            </div>
        </div>

        <div class="ui dropdown item">Factura<i class="dropdown icon"></i>
            <div class="menu">
                <a href="#">
                    <div class="item">Listado de Factura</div>
                </a>
                <a href="#">
                    <div class="item">Registrar Factura</div>
                </a>
            </div>
        </div>

        <div class="item rigth menu"><a href="#">Login</a></div>
        <div class="item rigth menu"><a href="#">Logout</a></div>

    </div>

    @yield('plantilla')

        <footer>Proyecto Diseñado Por Mi!</footer>
        <script>
            $('.ui.dropdown')
            .dropdown()
            ;
        </script>
        <br><br><br><br><br>
</body>
 </html>
