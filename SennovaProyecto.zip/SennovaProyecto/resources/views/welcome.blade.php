
@section('name')
    
    <center>
        <div class="centrar">
        <h1>Bienvenido a la papeleria Don Chucho!></h1><br>
        <h2></h2>
        <h2>Usted ingreso como: Usuario Principal </h2>
        <h2>Su correo Actual es:a@pepe.com </h2>
        <h2>Su rol actual es: Sin Rol </h2>
        <br><br>
        <img src="Img/Principal.jpg" alt="" width="500" height="300" class="centrar">
        </div>
    </center>



@endsection